﻿define("epi-ecf-ui/contentediting/editors/InventoryCollectionEditor", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",

    // epi commerce
    "./ReadOnlyCollectionEditor",

    "../viewmodel/InventoryCollectionEditorModel"
],
function (
    //dojo
    declare,
    lang,

    // epi commerce
    ReadOnlyCollectionEditor,

    InventoryCollectionEditorModel
) {
    return declare([ReadOnlyCollectionEditor], {
        // module: 
        //      epi-ecf-ui/contentediting/editors/InventoryCollectionEditor
        // summary:
        //      Represents the Read-only editor widget for product's inventory list.

        modelType: InventoryCollectionEditorModel
    });
});
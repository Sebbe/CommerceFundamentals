define("epi-ecf-ui/widget/CommandToolbar", [
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/promise/all",
    "dojo/when",
    "dijit/Toolbar",
    "dijit/layout/_LayoutWidget",
    "dijit/form/DropDownButton",
    "epi/shell/widget/_AddByDefinition"
], function (array, declare, lang, all, when, Toolbar, _LayoutWidget, DropDownButton, _AddByDefinition) {

    // Important: Mix in _LayoutWidget before Toolbar to get correct CSS classes from Toolbar
    return declare([_LayoutWidget, Toolbar, _AddByDefinition], {

        _commands: null,

        constructor: function(commands) {
            this._commands = commands;
        },

        buildRendering: function() {
            // summary:
            //      Constructs the toolbar container and starts the children setup process.
            // tags:
            //      protected

            this.inherited(arguments);

            // Setup the children items in the toolbar.
            when(this.setupChildren(), lang.hitch(this, function () {
                this.resize();
            }));
        },

        setupChildren: function() {
            // summary:
            //      Setup the items in the toolbar. Inheriting classes should extend this to add more items to the toolbar.
            // tags:
            //      protected

            var toolbarItems = [
            {
                name: "clipboard",
                type: "toolbargroup",
                parent: "leading",
                settings: {"class": "epi-groupedButtonContainer dijitInline" }
            }];

            toolbarItems = toolbarItems.concat(array.map(this._commands, function(command, index) {
                return {
                    name: "command" + index,
                    widgetType: "epi-ecf-ui/widget/CommandButton",
                    parent: command.toolbarGroup,
                    settings: { model: command, "class": "epi-flatButton epi-chromelessButton" },
                    title: command.label
                };
            }));

            return this.add(toolbarItems);        
        }
    });
});
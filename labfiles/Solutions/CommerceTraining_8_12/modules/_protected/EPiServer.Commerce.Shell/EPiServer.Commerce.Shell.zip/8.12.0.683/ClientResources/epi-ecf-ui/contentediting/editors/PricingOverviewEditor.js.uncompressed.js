define("epi-ecf-ui/contentediting/editors/PricingOverviewEditor", [
// Dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",

    "dojo/Deferred",

    "dojo/dom-construct",
    "dojo/Stateful",
    "dojo/when",

    // Dijit
    "dijit/layout/_LayoutWidget",
    "dijit/_TemplatedMixin",

    // DGrid
    "dgrid/OnDemandGrid",
    "dgrid/Selection",
    "dgrid/selector",
    "dgrid/extensions/ColumnResizer",
    "dgrid/editor",

    // EPi
    "epi/dependency",
    "epi/string",
    "epi/shell/_ContextMixin",
    "epi/shell/dgrid/_EditorMetadataMixin",
    "epi/shell/widget/_FocusableMixin",
    "epi/shell/widget/_ModelBindingMixin",
    "epi/shell/widget/dialog/Confirmation",

    //epi-CMS
    "epi-cms/dgrid/WithContextMenu",
    "epi-cms/dgrid/formatters",
    // epi commerce
    "../viewmodel/PricingOverviewEditorModel",
    "./SaleCodeEditor",
    "./MoneyEditor",

    //resources
    "epi/i18n!epi/cms/nls/commerce.widget.pricingoverview.grid",
    "epi/i18n!epi/cms/nls/commerce.widget.pricecollection.message"
],
function (
    // Dojo
    array,
    declare,
    lang,
    aspect,

    Deferred,

    domConstruct,
    Stateful,
    when,

    // Dijit
    _LayoutWidget,
    _TemplatedMixin,

    // DGrid
    OnDemandGrid,
    Selection,
    selector,
    ColumnResizer,
    editor,

    // EPi
    dependency,
    epiString,
    _ContextMixin,
    _EditorMetadataMixin,
    _FocusableMixin,
    _ModelBindingMixin,
    Confirmation,

    //epi-CMS
    WithContextMenu,
    formatters,

    // epi commerce
    PricingOverviewEditorModel,
    SaleCodeEditor,
    MoneyEditor,

    // Resources
    resources,
    messageResources
) {
    return declare([_LayoutWidget, _TemplatedMixin, _ModelBindingMixin, _FocusableMixin, _ContextMixin], {

        templateString: '<div class="epi-pricingOverviewEditor" data-dojo-attach-point="gridNode"></div>',

        grid: null,

        modelType: PricingOverviewEditorModel,

        itemType: "EPiServer.Commerce.Shell.ObjectEditing.InternalMetadata.PriceModel",

        activeEditor: null,

        includedColumns: ["Name", "Code", "MarketId", "PriceType", "MinQuantity", "PriceCode", "UnitPrice", "ValidDate"],

        editableColumns: ["MarketId", "PriceType", "MinQuantity", "PriceCode", "UnitPrice", "ValidDate"],

        postMixInProperties: function () {
            this.model = this.model || new this.modelType({
                itemType: this.itemType
            });
        },

        postCreate: function() {
            this.inherited(arguments);

            // Set up metadata capable grid type
            var EditorGrid = declare([OnDemandGrid, Selection, editor, _EditorMetadataMixin, ColumnResizer, WithContextMenu], {

                _filterProperties: function (properties, include) {
                    // Summary:
                    //      This is overridden to be able to handle rendering of complex type properties in
                    //      the grid. In our case it is a DateTimeRange object.

                    var result = this.inherited(arguments);
                    array.some(result, function(property){
                        if (property.uiType == null && property.properties.length > 0){
                            //When we find a property without any ui type and it has properties
                            //we know that we want to render it as a form.
                            property.uiType = "epi-ecf-ui/widget/NewPrice";
                            var metadataManager = this.metadataManager || dependency.resolve("epi.shell.MetadataManager");
                            property.settings = {
                                metadata:  metadataManager.getMetadataForType(property.modelType)
                            };
                            return true;
                        }
                    }, this);
                    return result;
                }
            });

            // Get metadata for itemType
            when(this.model.metadataManager.getMetadataForType(this.itemType), lang.hitch(this, function(metadata) {
                // Set up columns object with one column for context menu
                var columns = [{
                    field: "epiGridAction",
                    renderHeaderCell: function() {}, // no header
                    formatter: function() {
                        return formatters.menu({
                            title: resources.commands.title
                        });
                    },
                    className: "epi-columnNarrow",
                    sortable: false
                    }],
                    store = dependency.resolve("epi.storeregistry").get("epi.commerce.price"),
                    // Create grid
                    grid = this.grid = new EditorGrid({
                        selectionMode: "none",
                        store: store,
                        minWidth: 100,
                        noDataMessage: resources.nodatamessage,
                        "class": "epi-plain-grid epi-plain-grid--small-header-font",
                        columns: columns,
                        metadata: {
                            properties: metadata.properties,
                            gridIncluded: this.includedColumns,
                            gridEditable: this.editableColumns
                        }
                    });

                this.model.generateFormatters(grid.columns, grid.metadata.gridEditable);
                domConstruct.place(this.grid.domNode, this.gridNode);
                this._setupEvents(grid);

                this._setupContextMenu();

                // Update the grid query in case the contentlink value set but the model or setupEvent hasn't been initialized.
                when(this.getCurrentContext(), lang.hitch(this, function(currentContext){
                    if (this.model.get("contentLink") !== currentContext.id){
                        //we're setting the value, since that will update the models content link
                        //which will update the grids query
                        this.set("value", currentContext.id);
                    } else {
                        //the model already has correct contentLink. Here we just make sure
                        //the grid gets the correct query before starting it
                        this._updateGridQuery(grid);
                    }
                    grid.startup();
                    this.own(
                        //we need to wait until after startup to attach to "edit" as that function is created
                        //during startup.
                        aspect.before(grid, "edit", lang.hitch(this, function(cell){
                            //we save this value to show in the grid while editing in the popup.
                            this.currentEditorHtmlValue = cell.innerHTML;
                        }))
                    );
                }));
            }));
            this._setMarkets();
        },

        _setupEvents: function(grid){
            var customerPriceGroupType = 2;
            this.own(grid,
                grid.on("dgrid-editor-show", lang.hitch(this, function(e) {
                    if(e.editor instanceof SaleCodeEditor) {
                        //The salecode editor should be updated according to what priceType has been set
                        e.editor.showDropDown(e.cell.row.data.priceType === customerPriceGroupType);
                    } else if (e.editor instanceof MoneyEditor){
                        e.editor.setCurrencySelections(e.cell.row.data.marketId);
                    }
                    this.activeEditor = e.editor;
                    this._showEditorInPopup(e);
                })),
                grid.on("dgrid-datachange", lang.hitch(this, function(e){
                    //invalid value / validation error will result in no changes to the price row
                    if (this.activeEditor && this.activeEditor.isValid && !this.activeEditor.isValid()) {
                        e.preventDefault();
                    }
                })),
                grid.on(".epi-iconContextMenu:click", lang.hitch(this, this.onContextMenuClick)),
                this.model.watch("contentLink", lang.hitch(this, this._changeGridQuery)),
                this.model.watch("marketId", lang.hitch(this, this._changeGridQuery)),
                this.model.watch("priceCode", lang.hitch(this, this._changeGridQuery)),
                this.model.on("itemAdded", lang.hitch(this, function(e) {
                    this.grid.refresh();
                })),
                this.model.on("itemsRemoved", lang.hitch(this, function(e) {
                    this.grid.refresh();
                })),
                // Listen remove command event
                this.model.on("removeCommandEvent", lang.hitch(this, function() {
                    // Show confirmation dialog to confirm delete price item
                    when(this._showConfirmation(resources.deleteconfirmation.pricetitle, resources.deleteconfirmation.pricedescription), lang.hitch(this, function() {
                        if (this.model) {
                            return this.model.removeItems([this.selectedPrize]);
                        }
                    }));
                })),
                this.model.on("duplicateCommandEvent", lang.hitch(this, function() {
                    if (this.selectedPrize && this.model) {
                        // Clone the model and remove its ID so that JsonRest understands this is a new object
                        // and not an attempt to update an existing object
                        var clone = lang.clone(this.selectedPrize);
                        delete clone.id;

                        this.model.addItem(clone);
                    }
                }))
            );
        },

        _updateGridQuery: function (grid) {
            // summary:
            //      update the query for grid.
            //  tags:
            //      private

            var queryOptions = this.model._createQueryOptions();
            grid.set("query", queryOptions.query, queryOptions.options);
        },

        _changeGridQuery: function (property, oldValue, newValue) {
            // summary:
            //      event to update the grid query.
            //  tags:
            //      private

            if (oldValue !== newValue) {
                this._updateGridQuery(this.grid);
            }
        },

        _showEditorInPopup: function(e){
            //we're wrapping the editor in a div to give it a popup styling.
            var popupElement = domConstruct.create("div", { "class" : "epi-dgrid-popup"}, e.cell.element, "last");
            var editorWrapper = domConstruct.create("div", { "class" : "epi-dgrid-popup__content"}, popupElement, "last");
            domConstruct.place(e.editor.domNode, editorWrapper);
            domConstruct.place(this.currentEditorHtmlValue, e.cell.element, "first");
            var beforeBlurHandle = aspect.before(e.editor, "onBlur", function(){
                //we need to move the editor back to the grid before "blur"
                //so that the dgrid/editor plugin can do its save/"hide editor" magic

                //move the editor to a temporary div first to prevent issues in IE
                //when we move the editors domNode as the only child to e.cell.element
                var tempDiv = domConstruct.create("div");
                domConstruct.place(e.editor.domNode, tempDiv);
                //then move it as the only child to the element we're editing.
                domConstruct.place(e.editor.domNode, e.cell.element, "only");
                beforeBlurHandle.remove();
            });
        },

        _setupContextMenu: function(){
            this.commands = this.model.getCommands(this.grid, "context");

            this.grid.contextMenu.addProvider(new Stateful({
                commands: this.commands
            }));
        },

        _setMarkets: function(){
            if(!this.get("markets")){
                var marketStore = dependency.resolve("epi.storeregistry").get("epi.commerce.market");
                marketStore.query().then(lang.hitch(this, function(marketList){
                    this.set("markets", marketList);
                }));
            }
        },

        _noDataMessage: resources.nodatamessage,

        _setValueAttr: function (value) {
            // summary:
            //      Value setter.
            // description:
            //      Push value to the model to be its data.
            //  tags:
            //      private

            this._set("value", value);

            if (this.model) {
                this.model.set("contentLink", value);
            }
        },

        _setMarketIdAttr: function (value) {
            // summary:
            //      Value setter.
            // description:
            //      Push value to the model to be its data.
            //  tags:
            //      private

            this.model.set("marketId", value);
        },

        _setPriceCodeAttr: function (value) {
            // summary:
            //      Value setter.
            // description:
            //      Push value to the model to be its data.
            //  tags:
            //      private

            this.model.set("priceCode", value);
        },

        _showConfirmation: function (title, description) {
            // summary:
            //      Wrap epi.shell.widget.dialog.Confirmation for short type
            //      and return deferred object
            // description:
            //      String: Text to display on dialog
            // tags:
            //      private

            var deferred = new Deferred();

            var dialog = new Confirmation({
                destroyOnHide: true,
                title: epiString.toHTML(title),
                description: epiString.toHTML(description),
                onAction: function (confirmed) {
                    if (confirmed) {
                        deferred.resolve();
                    } else {
                        deferred.cancel();
                    }
                }
            });
            dialog.show();

            return deferred.promise;
        },

        addPrice: function (newPrice) {
            // summary:
            //      Add new price to the grid
            // tags:
            //      protected

            // Set default value for marketId column
            var markets = this.get("markets");
            if (!newPrice.marketId && markets && markets.length > 0) {
                var defaultMarket = markets[0];
                newPrice = lang.mixin(newPrice, {
                    marketId: defaultMarket.id,
                    currency: defaultMarket.currencies[0].value
                });
            }

            // Insert new row in grid then edit
            return this.model.addItem(newPrice);
        },

        onContextMenuClick: function(e){
            this.selectedPrize = this.grid.row(e).data;
        },

        resize: function () {
            this.inherited(arguments);
            if (this.grid){
                this.grid.resize();
            }
        }
    });
});

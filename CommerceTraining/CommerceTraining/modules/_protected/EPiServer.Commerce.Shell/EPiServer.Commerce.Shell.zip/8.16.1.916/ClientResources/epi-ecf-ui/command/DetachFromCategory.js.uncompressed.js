﻿define("epi-ecf-ui/command/DetachFromCategory", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Deferred",
    "dojo/promise/all",
    "dojo/topic",
    "dojo/when",
    
// epi-shell
    "epi/dependency",
    "epi/shell/command/_Command",
    "epi/shell/command/_SelectionCommandMixin",
    "epi/shell/TypeDescriptorManager",
    "epi/shell/widget/dialog/Alert",

// epi-cms
    "epi-cms/core/ContentReference",

// epi-ecf-ui
    "../contentediting/ModelSupport",

// Resources
    "epi/i18n!epi/cms/nls/commerce.command.detachfromcategory"
],

function (
// dojo
    array,
    declare,
    lang,
    Deferred,
    promiseAll,
    topic,
    when,

// epi-shell
    dependency,
    _Command,
    _SelectionCommandMixin,
    TypeDescriptorManager,
    Alert,

// epi-cms
    ContentReference,

// epi-ecf-ui
    ModelSupport,

// Resources
    res
) {

    // module:
    //      epi-cms/command/PasteContent
    // summary:
    //      A command that pastes whats in the clip board onto the current selection.
    // tags:
    //      public

    return declare([_Command, _SelectionCommandMixin], {

        // label: [readonly] String
        //      The action text of the command to be used in visual elements.
        label: res.label,

        // categoryLink: String
        //      Optional. Definies what category the selection should be detached from.
        categoryLink: null,

        // iconClass: [readonly] String
        //      The icon class of the command to be used in visual elements.
        iconClass: "epi-iconDetach",
        
        _store: null,

        postscript: function () {
            // summary:
            //      init registry and _store
            // tags:
            //      public override
            this.inherited(arguments);
            if (!this._store) {
                var registry = dependency.resolve("epi.storeregistry");
                this._store = registry.get("epi.commerce.relation");
            }
        },

        _execute: function() {
            // summary:
            //      Executes this command; publishes a change view request to change to the create content view.
            // tags:
            //      protected override
            var categoryLink = this.categoryLink ||
                                when(this.model.currentContentService.getCurrentContext(), lang.hitch(this, function (currentContext) {
                                    return currentContext.id;
                                }));
            var nodeContentLink = new ContentReference(categoryLink).createVersionUnspecificReference();

            var deferreds = array.map(this.selection.data, function(selectionItem) {
                return when(this._store.query(this._getQuery(selectionItem.data.contentLink)), lang.hitch(this, function(relations) {
                    return promiseAll(array.map(relations, function(relation) {
                        var targetContentLink = new ContentReference(relation.target);
                        if (targetContentLink.id === nodeContentLink.id) {
                            return this._store.remove(relation.id).then(function(){
                                topic.publish("relationChanged", relation);
                            });
                        }
                    }, this));
                }));
            }, this);

            promiseAll(deferreds);
        },

        _onModelChange: function() {
            // summary:
            //		Updates canExecute after the model has been updated.
            // tags:
            //		protected override

            var deferreds = [];
            var anythingSelected = this.selection.data.length > 0;
            array.forEach(this.selection.data, function(selectionItem) {
                var deferred = new Deferred();
                deferreds.push(deferred.promise);
                if (selectionItem.type !== "epi.cms.contentdata") {
                    deferred.resolve(false);
                }

                if (!this.isUsedByCollectionEditor) {
                    when(this.model.currentContentService.getCurrentContext(), lang.hitch(this, function (currentContext) {
                        if (ContentReference.compareIgnoreVersion(selectionItem.data.parentLink, currentContext.id) || !selectionItem.data.properties.isRelatedToCurrentCategory) {
                            deferred.resolve(false);
                        }
                    }));
                }

                when(this._store.query(this._getQuery(selectionItem.data.contentLink)), lang.hitch(this, function (relations) {

                    if (this._typeIsAssignableFrom(selectionItem.data.typeIdentifier, ModelSupport.contentTypeIdentifier.nodeContentBase)) {
                        deferred.resolve(relations.length > 0);
                    }
                    deferred.resolve(relations.length > 1);
                }));

            }, this);
            promiseAll(deferreds).then(lang.hitch(this, function (results) {
                var anyFailingSelections = array.some(results, function(result) {
                    return !result;
                });
                this.set("canExecute", anythingSelected && !anyFailingSelections);
            }));
        },

        _typeIsAssignableFrom: function (/*string*/ type, /*string*/ baseTypeToSupport) {
            return TypeDescriptorManager.isBaseTypeIdentifier(type, baseTypeToSupport);
        },

        _getQuery: function(contentLink) {
            return { referenceId: contentLink, relationTypes: [ModelSupport.relationType.node] };
        }
    });
});
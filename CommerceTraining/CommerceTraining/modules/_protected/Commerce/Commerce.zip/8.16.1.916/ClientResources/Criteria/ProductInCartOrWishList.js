﻿/// <reference path="~/dojo-vsdoc.js" />
(function() {
    return {
        createUI: function (namingContainer, container, settings, callback) {
            var self = this;
                self.languageKeys = '/Commerce/visitorgroups/productincartorwishlist/productcoderequiredtext,/Commerce/visitorgroups/productincartorwishlist/categoryrequiredtext,' +
                            '/Commerce/visitorgroups/productincartorwishlist/propertynamerequiredtext,/Commerce/visitorgroups/productincartorwishlist/propertyvaluerequiredtext,' +
                            '/Commerce/visitorgroups/productincartorwishlist/comparisonrequiredtext';

            this.prototype.createUI.apply(this, arguments);
        },

        uiCreated: function (namingContainer, settings) {
            var self = this;

            self._initialize(namingContainer, null, settings);
        },

        //add validation errors for required fields
        validate: function (namingContainer) {
            var comparisonType = dijit.byId(namingContainer + 'ComparisonType');
            var category = dijit.byId(namingContainer + 'Category');
            var productName = dijit.byId(namingContainer + 'ProductName');
            var property = dijit.byId(namingContainer + 'Property');
            var propertyValue = dijit.byId(namingContainer + 'PropertyValue');

            var comparisonRequiredText = this.translatedText['/Commerce/visitorgroups/productincartorwishlist/comparisonrequiredtext'];
            var productCodeRequiredText = this.translatedText['/Commerce/visitorgroups/productincartorwishlist/productcoderequiredtext'];
            var categoryRequiredText = this.translatedText['/Commerce/visitorgroups/productincartorwishlist/categoryrequiredtext'];
            var propertyNameRequiredText = this.translatedText['/Commerce/visitorgroups/productincartorwishlist/propertynamerequiredtext'];
            var propertyValueRequiredText = this.translatedText['/Commerce/visitorgroups/productincartorwishlist/propertyvaluerequiredtext'];
            var validationErrors = this.prototype.validate.apply(this, arguments);

            if (!comparisonType.value || epiJQuery.trim(comparisonType.value).length == 0) {
                validationErrors.Add(comparisonRequiredText, comparisonType);
            }
            else {
                if (comparisonType.value == "Product") {
                    if (!productName.value || epiJQuery.trim(productName.value).length == 0) {
                        validationErrors.Add(productCodeRequiredText, productName);
                    }
                }
                else if (comparisonType == "FromCategory") {
                    if (!category.value || epiJQuery.trim(category.value).length == 0) {
                        validationErrors.Add(categoryRequiredText, category);
                    }
                }
                else {
                    if (!property.value || epiJQuery.trim(property.value).length == 0)
                        validationErrors.Add(propertyNameRequiredText, property);
                    if (!propertyValue.value || epiJQuery.trim(propertyValue.value).length == 0)
                        validationErrors.Add(propertyValueRequiredText, propertyValue);
                }
            }
            return validationErrors;
        },

        //initialize this criterion
        _initialize: function (namingContainer, container, settings) {
            var self = this;

            if (!settings) {
                settings = {};  // first time drop in dropzone
            }

            var _updateInputControls = function (keyName, namingContainer, settings) {
                dojo.style(dojo.byId(namingContainer + 'CategoryContainer'), 'display', 'none');
                dojo.style(dojo.byId(namingContainer + 'ProductNameContainer'), 'display', 'none');
                dojo.style(dojo.byId(namingContainer + 'HasPropertyAndValueContainer'), 'display', 'none');

                dijit.byId(namingContainer + 'ProductName').set('value', settings.ProductName || '');
                dijit.byId(namingContainer + 'Property').set('value', settings.Property || '');
                dijit.byId(namingContainer + 'PropertyValue').set('value', settings.PropertyValue || '');

                switch (keyName) {
                    case 'Product':
                        dojo.style(dojo.byId(namingContainer + 'ProductNameContainer'), 'display', '');
                        break;
                    case 'FromCategory':
                        dojo.style(dojo.byId(namingContainer + 'CategoryContainer'), 'display', '');
                        break;
                    case 'HasPropertyAndValue':
                        dojo.style(dojo.byId(namingContainer + 'HasPropertyAndValueContainer'), 'display', '');
                        break;
                    default:
                        dojo.style(dojo.byId(namingContainer + 'ProductNameContainer'), 'display', '');
                        break;
                };
            };

            var comparisonTypeDijit = dijit.byId(namingContainer + 'ComparisonType');

            _updateInputControls(comparisonTypeDijit.value, namingContainer, settings);

            var eventHandler = function () {
                _updateInputControls(comparisonTypeDijit.value, namingContainer, settings);
            };

            dojo.connect(comparisonTypeDijit, 'onChange', self, eventHandler);
        }
    }
})();